from django.apps import AppConfig


class MynewsdetailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mynewsdetail'
