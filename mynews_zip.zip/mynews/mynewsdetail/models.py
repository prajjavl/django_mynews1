from django.db import models
from django.db.models.deletion import CASCADE
from django.shortcuts import redirect

# Create your models here.

class CompanyDetails(models.Model):
    email = models.EmailField(max_length=50)
    phone = models.CharField(max_length=20)
    address = models.TextField()
    link = models.CharField(max_length=100)
    date = models.DateTimeField()

    def __str__(self):
        return self.link

    class Meta:
        verbose_name_plural = "CompanyDetails"

class SocialLink(models.Model):
    contactdetails = models.ForeignKey(CompanyDetails, on_delete=models.CASCADE)
    link_name = models.CharField(max_length=100, default='null')
    link = models.CharField(max_length=100)
    

    def __str__(self):
        return self.contactdetails.link



   




