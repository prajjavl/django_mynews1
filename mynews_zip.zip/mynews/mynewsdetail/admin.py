from django.contrib import admin
from django.db import models
from .models import CompanyDetails, SocialLink

# Register your models here.

class SocialLinkAdmin(admin.StackedInline):
    model = SocialLink

@admin.register(CompanyDetails)
class CompanyDetailsinline(admin.ModelAdmin):
    inlines = [SocialLinkAdmin]
    class Meta:
        model = CompanyDetails

admin.site.register(SocialLink)


