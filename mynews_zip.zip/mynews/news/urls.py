from django . urls import include, path
from . import views

urlpatterns = [
   path('index', views.index, name='index'),
   path('<int:id>/sports', views.sports, name='sports'),
   path('<int:news_id>/detail', views.detail, name='detail'),
   path('register', views.register, name='register')

]
