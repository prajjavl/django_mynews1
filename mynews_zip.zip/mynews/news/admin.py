from django.contrib import admin
from django.db import models
from .models import AllCategory, AllNews

# Register your models here.
admin.site.register(AllCategory)

@admin.register(AllNews)
class AllNewsAdmin(admin.ModelAdmin):
    list_display = ('category_name', 'title', 'desc', )

