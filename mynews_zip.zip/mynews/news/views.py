from django.shortcuts import redirect, render
from django.contrib.auth.models import User, auth
from. models import AllNews, AllCategory



def index(request):
    allnews = AllNews.objects.all().order_by('-id')[:6]
    # print(allnews.query)
    return render(request, 'index.html', {'allnews': allnews})

def detail(request, news_id):
    alldetail = AllNews.objects.get(id = news_id)
    # print(detail)
    return render(request, 'detail.html', {'alldetail' : alldetail})

    
def register(request):
    return render(request, 'register.html')

def sports(request,id):
    catid = AllCategory.objects.get(id=id)
    basicNews = AllNews.objects.filter(category_name__icontains = catid.category_name)
    return render(request, 'sports.html', {'basicNews': basicNews})
  

  
# Create your views here.
def register(request):
    if request.method=='POST':
        name = request.POST['name']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        user = User.objects.create_user(name=name,email=email,password=password1)
        user.save();
        print("thank you")
        return redirect('/')
   
    else:
        return render(request,'index.html')

