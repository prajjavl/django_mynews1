from django.db import models
from django.db.models.deletion import CASCADE
from django.shortcuts import redirect
from django.urls import reverse


# Create your models here.
   

class AllCategory(models.Model):
    category_name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.category_name
    

class AllNews(models.Model):
    category_name = models.ForeignKey(AllCategory, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    img = models.ImageField(upload_to='img/')
    desc = models.TextField()

    def __str__(self):
        return str(self.category_name)

    class Meta:
        verbose_name_plural = "AllNews"







    
